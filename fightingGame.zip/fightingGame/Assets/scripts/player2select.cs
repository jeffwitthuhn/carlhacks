﻿using UnityEngine;
using System.Collections;

public class player2select : MonoBehaviour {
	public static bool player2selected;
	Vector3 pos;
	// Use this for initialization
	void Start () {
		gameObject.transform.position = new Vector3 (-5, 2, 1);

		player2selected = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (!player2selected) {
			pos = gameObject.transform.position;

			
			if (Input.GetKeyDown (KeyCode.W)  && pos.y + 2 < 5) {
					gameObject.transform.position = new Vector3 (pos.x, pos.y + 2, pos.z);

			}
			if (Input.GetKeyDown (KeyCode.S)  && pos.y - 2 > 1) {

					gameObject.transform.position = new Vector3 (pos.x, pos.y - 2, pos.z);

			}
			if (Input.GetKeyDown (KeyCode.D)  && pos.x + 2 < 6) {

					gameObject.transform.position = new Vector3 (pos.x + 2, pos.y, pos.z);

			}
			if (Input.GetKeyDown (KeyCode.A) && pos.x - 2 > -6) {

					gameObject.transform.position = new Vector3 (pos.x - 2, pos.y, pos.z);

			}
			if (Input.GetKeyDown (KeyCode.Space) && pos.x < -4 && pos.y > 3) {
				Game.P2choice = "anda";				GetComponent<AudioSource>().Play ();

				player2selected = true;
			}
			if (Input.GetKeyDown (KeyCode.Space) && pos.x < -4 && pos.y < 3) {
				Game.P2choice = "jha";
				GetComponent<AudioSource>().Play ();

				player2selected = true;
			}
		} 
		else {
			if(Input.GetKeyDown (KeyCode.Escape))
				player2selected=false;
			
		}
		
	}
}
