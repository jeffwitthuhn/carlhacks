﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class Game : MonoBehaviour {
	GameObject anda,jha;
	float barheight;
	float P1picx;
	float P2picx;
	float P1barxleft, P1barxright;
	float P2barxleft, P2barxright;
	GameObject andahead, jhahead, hpbarelement;
	GameObject P1picture, P2picture;
	float P1hp, P2hp;
	bool yellow, orange, red;
	bool yellow2,orange2,red2;
	public static GameObject P1, P2; 
	public static string P1choice, P2choice;
	List<bool> P1bardestroyed,P2bardestroyed;
	// Use this for initialization
	void Start () {
		P1bardestroyed=new List<bool>(0);
		P2bardestroyed= new List<bool>(0);
		yellow = orange = red = red2=orange2=yellow2=false;
		barheight = 7.35f;
		P1picx = -6f;
		P2picx = 6f;
		P1barxleft = -5.25f;
		P1barxright = -1;
		P2barxleft = 1;
		P2barxright = 5.25f;
		andahead =(GameObject) Resources.Load ("andahead");
		jhahead =(GameObject) Resources.Load ("jhahead");
		hpbarelement = (GameObject)Resources.Load ("HPelement");
		anda = (GameObject)Resources.Load ("anda");
		jha=(GameObject)Resources.Load ("jha");
		for (int i=0; i<100; i++) {
			GameObject P1bar, P2bar;
			P1bardestroyed.Add (false);
			P2bardestroyed.Add (false);

			P1bar = GameObject.Instantiate(hpbarelement) as GameObject;
			P1bar.GetComponent<SpriteRenderer>().color=new Color(0,255,0);
			P1bar.transform.position = new Vector3(P1barxleft+i*0.0425f, barheight,-0.5f);
			P1bar.name= "P1bar"+i.ToString ();
			P2bar = GameObject.Instantiate(hpbarelement) as GameObject;
			P2bar.GetComponent<SpriteRenderer>().color=new Color(0,255,0);
			P2bar.transform.position = new Vector3(P2barxright-i*0.0425f, barheight,-0.5f);
			P2bar.name= "P2bar"+i.ToString();;
		}


		//P1choice = "anda";
		//P2choice = "jha";
		if (P1choice == "anda") {
			Debug.Log ("spawnanda1");
			anda.name = "P1";
			anda.transform.GetChild (0).gameObject.tag="P1";
			anda.transform.GetChild (0).gameObject.name="P1atk";
			P1 = GameObject.Instantiate (Resources.Load (P1choice,typeof(GameObject))) as GameObject;
			P1.transform.position=new Vector3(-4,0,0);
			P1picture=GameObject.Instantiate (andahead);
			P1picture.transform.position = new Vector3(P1picx,barheight,-1f);


		} 
		else if(P1choice == "jha"){
			Debug.Log ("spawnjha1");

			jha.name = "P1";
			jha.transform.GetChild (0).gameObject.tag="P1";
			jha.transform.GetChild (0).gameObject.name="P1atk";
			P1 = GameObject.Instantiate (Resources.Load (P1choice,typeof(GameObject))) as GameObject;
			P1.transform.position=new Vector3(-4,0,0);
			P1picture=GameObject.Instantiate (jhahead);
			P1picture.transform.position = new Vector3(P1picx,barheight,-1f);

		}
		if (P2choice == "anda") {
			Debug.Log ("spawnanda2");

			anda.name = "P2";
			anda.transform.GetChild (0).gameObject.tag="P2";
			anda.transform.GetChild (0).gameObject.name="P1atk";
			P2 = GameObject.Instantiate (Resources.Load (P2choice,typeof(GameObject))) as GameObject;
			P2.transform.position=new Vector3(4,0,0);

			P1picture=GameObject.Instantiate (andahead);
			P1picture.transform.position = new Vector3(P2picx,barheight,-1f);

		} 
		else if(P2choice == "jha"){
			Debug.Log ("spawnjha2");

			jha.name = "P2";
			jha.transform.GetChild (0).gameObject.tag="P2";
			jha.transform.GetChild (0).gameObject.name="P1atk";
			P2 = GameObject.Instantiate (Resources.Load (P2choice,typeof(GameObject))) as GameObject;
			P2.transform.position=new Vector3(4,0,0);
			P1picture=GameObject.Instantiate (jhahead);
			P1picture.transform.position = new Vector3(P2picx,barheight,-1f);

		}
	}
	
	// Update is called once per frame
	void Update () {
		bool p1depleted = true;
		bool p2depleted = true;
		for(int i=99; i>=0; i--){
			if(!P1bardestroyed[i])
				p1depleted=false;
			if(!P2bardestroyed[i])
				p2depleted=false;
		}
		if (p1depleted||P1hp<0) {
			if(P2choice=="anda"){
				Application.LoadLevel (3);
			}
			else {
				Application.LoadLevel (4);
			}
		}
		if (p2depleted||P2hp<0){
			if(P1choice=="anda"){
				Application.LoadLevel (3);
			}
			   else {
				Application.LoadLevel (4);

			}
		}
		if (P1choice == "anda") {
			P1hp=P1.GetComponent<andascript>().hp;
		}
		else {
			P1hp=P1.GetComponent<jhascript>().hp;

		}
		if (P2choice == "anda") {
			P2hp = P2.GetComponent<andascript> ().hp;

		}
		else {
			P2hp=P2.GetComponent<jhascript>().hp;

		}
		for(int i=99; i>=0; i--){
			if(P1hp<(i+1)*10&&!P1bardestroyed[i])
				GameObject.Find ("P1bar"+i.ToString ()).GetComponent<SpriteRenderer>().enabled=false;
		}
		for(int i=99; i>=0; i--){
			if(P2hp<(i+1)*10&&!P1bardestroyed[i])
				GameObject.Find ("P2bar"+i.ToString ()).GetComponent<SpriteRenderer>().enabled=false;
		}
		if(P1hp<600&&P1hp>300&&!yellow){
			for(int i =0; i<P1hp/10; i++)
				GameObject.Find ("P1bar"+i.ToString()).GetComponent<SpriteRenderer>().color = new Color (255,255,0);
			yellow=true;
			
		}
		else if(P1hp<300&&P1hp>100&&!orange){
			for(int i =0; i<P1hp/10; i++)
				GameObject.Find ("P1bar"+i.ToString()).GetComponent<SpriteRenderer>().color = new Color (255,100,0);
			orange=true;
			
		}
		else if(P1hp<100&&!red){
			for(int i =0; i<P1hp/10; i++)
				GameObject.Find ("P1bar"+i.ToString()).GetComponent<SpriteRenderer>().color = new Color (255,0,0);
			red = true;
			
		}
		if(P2hp<600&&P2hp>300&&!yellow2){
			for(int i =0; i<P2hp/10; i++)
				GameObject.Find ("P2bar"+i.ToString()).GetComponent<SpriteRenderer>().color = new Color (255,255,0);
			yellow=true;
			
		}
		else if(P2hp<300&&P2hp>100&&!orange2){
			for(int i =0; i<P2hp/10; i++)
				GameObject.Find ("P2bar"+i.ToString()).GetComponent<SpriteRenderer>().color = new Color (255,100,0);
			orange=true;
			
		}
		else if(P2hp<100&&!red2){
			for(int i =0; i<P2hp/10; i++)
				GameObject.Find ("P2bar"+i.ToString()).GetComponent<SpriteRenderer>().color = new Color (255,0,0);
			red = true;
			
		}


	}
}
