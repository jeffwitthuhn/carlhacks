﻿using UnityEngine;
using System.Collections;

public class zerowan : MonoBehaviour {
	public bool direction;
	Vector3 pos;
	public float speed;
	// Use this for initialization
	void Start () {
		speed = 6;
		Destroy (gameObject, 3f);
		GetComponent<Rigidbody2D> ().velocity = new Vector3 (0, 3, 0);
	}
	
	// Update is called once per frame
	void Update () {
		pos = gameObject.transform.position;
		if (direction)
			pos.x += speed * Time.deltaTime;
		else
			pos.x -= speed * Time.deltaTime;
		gameObject.transform.position = pos;
		
	}
}
