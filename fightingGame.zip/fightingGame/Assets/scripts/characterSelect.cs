﻿using UnityEngine;
using System.Collections;

public class characterSelect : MonoBehaviour {

	// Use this for initialization

	// Update is called once per frame
	void Update () {
		if (player1select.player1selected && player2select.player2selected) {
			Application.LoadLevel (2);
		}
	}
}
