﻿using UnityEngine;
using System.Collections;

public class letters : MonoBehaviour {
	public float spinspeed; 
	public float floatingspeed;
	float max, min;
	bool direction;
	Vector3 pos;
	// Use this for initialization
	void Start () {
		spinspeed = Random.Range (100, 500);
		floatingspeed = 1;
		pos = gameObject.transform.position;
		max = pos.y + 0.5f;
		min = pos.y - .1f;
		if (Random.Range (0, 2)>0)
			direction = true;
		else
			direction = false;
	}
	
	// Update is called once per frame
	void Update () {
		pos = gameObject.transform.position;
		gameObject.transform.Rotate (new Vector3(0,0,spinspeed*Time.deltaTime));
	 if (direction){
			pos.y +=floatingspeed*Time.deltaTime;
		}
		else {
			pos.y -=floatingspeed*Time.deltaTime;
		}
		if(pos.y<min) direction = true;
		else if (pos.y>max) direction = false;
		gameObject.transform.position = pos;
	}
}
