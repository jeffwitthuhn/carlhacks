﻿using UnityEngine;
using System.Collections;

public class opening : MonoBehaviour {
	
	void Update(){
		if(Input.anyKeyDown)
			Application.LoadLevel (1);

	}
}
