﻿using UnityEngine;
using System.Collections;

public class player1select : MonoBehaviour {
	bool axisinuse;
	public static bool player1selected;
	Vector3 pos;
	// Use this for initialization
	void Start () {
		gameObject.transform.position = new Vector3 (-5, 4, 1);
		axisinuse = false;
		player1selected = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (!player1selected) {
			pos = gameObject.transform.position;
			if (axisinuse && Input.GetAxisRaw ("DpadY") == 0)
				axisinuse = false;
	
			if (Input.GetAxisRaw ("DpadY") > 0 && pos.y + 2 < 5) {
				if (!axisinuse)
					gameObject.transform.position = new Vector3 (pos.x, pos.y + 2, pos.z);
				axisinuse = true;
			}
			if (Input.GetAxisRaw ("DpadY") < 0 && pos.y - 2 > 1) {
				if (!axisinuse)
					gameObject.transform.position = new Vector3 (pos.x, pos.y - 2, pos.z);
				axisinuse = true;
			}
			if (Input.GetAxisRaw ("DpadX") > 0 && pos.x + 2 < 6) {
				if (!axisinuse)
					gameObject.transform.position = new Vector3 (pos.x + 2, pos.y, pos.z);
				axisinuse = true;
			}
			if (Input.GetAxisRaw ("DpadX") < 0 && pos.x - 2 > -6) {
				if (!axisinuse)
					gameObject.transform.position = new Vector3 (pos.x - 2, pos.y, pos.z);
				axisinuse = true;
			}
			if (Input.GetKeyDown (KeyCode.JoystickButton0) && pos.x < -4 && pos.y > 3) {
				Game.P1choice = "anda";
				GetComponent<AudioSource>().Play ();
				player1selected = true;
			}
			if (Input.GetKeyDown (KeyCode.JoystickButton0) && pos.x < -4 && pos.y < 3) {
				Game.P1choice = "jha";
				GetComponent<AudioSource>().Play ();
				player1selected = true;
			}
		} 
		else {
			if(Input.GetKeyDown (KeyCode.JoystickButton1))
				player1selected=false;

		}

	}
}
