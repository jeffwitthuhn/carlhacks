﻿using UnityEngine;
using System.Collections;

public class atkboxscript : MonoBehaviour {
	public float attackdamage;

}

