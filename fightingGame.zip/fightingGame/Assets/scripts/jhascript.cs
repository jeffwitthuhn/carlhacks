﻿using UnityEngine;
using System.Collections;

public class jhascript : MonoBehaviour {

	public bool right;
	public bool ducking;
	public bool alive;
	public bool upatk;
	public bool downatk;
	public bool frontatk;
	public bool atk; 
	public bool shoot;
	public bool shooting; 
	public bool jumping;
	public bool walking;
	public int player; 
	public float speed;
	public float jumpforce;
	public float hp;
	public float beamdmg;
	public float hardatkdmg;
	public float softatkdmg;
	float waittime;
	float elapsedtime;
	bool counting;
	bool axisinuse;
	Vector3 pos; 
	Vector3 scale; 
	Animator playeranimator;
	Rigidbody2D playerrigidbody;
	atkboxscript boxdamage;
	string enemyboxname;
	string myboxname;
	AudioSource[] audiosources;
	
	// Use this for initialization
	void Start () {
		audiosources = GetComponents<AudioSource> ();

		boxdamage=gameObject.transform.GetChild (0).gameObject.GetComponent<atkboxscript>();
		if (gameObject.name.Substring (0,2) == "P1") {
			player = 1;
			enemyboxname="P2";
			myboxname="P1";

		} 
		else {
			player = 2;
			enemyboxname="P1";
			myboxname="P2";


		}
		if (player == 1)
			right = true;
		else {
			right = false; 
			scale=gameObject.transform.localScale;
			scale.x=-4;
			gameObject.transform.localScale=scale;
		}
		playerrigidbody = GetComponent<Rigidbody2D> ();
		playeranimator = GetComponent<Animator> ();
		alive = true;
		upatk = false;
		downatk = false;
		frontatk = false;
		atk = false;
		shoot = false;
		shooting = false;
		jumping = false;
		walking = false;
		counting = false;
		axisinuse = false;
		waittime = 1.1f;
		speed = 5;
		jumpforce = 10;
		beamdmg = 10;
		hardatkdmg = 40;
		softatkdmg = 10;
		hp = 1000;
	}
	
	// Update is called once per frame
	void Update () {
		upatk = false;
		downatk = false;
		frontatk = false;
		atk = false;
		jumping = false;
		walking = false;
			boxdamage.attackdamage = 0;
			pos = gameObject.transform.position;
			scale = gameObject.transform.localScale;
			if (player == 1) {
				if (Input.GetAxisRaw("DpadY")> 0 &&pos.y<5&& playerrigidbody.velocity.y >-0.1f&&playerrigidbody.velocity.y<0.1f) {
					jumping = true;
				audiosources[1].Play();
					if(!axisinuse)
						playerrigidbody.AddForce (new Vector2 (0, jumpforce), ForceMode2D.Impulse);
					axisinuse=true;
				}
				if(axisinuse&&Input.GetAxisRaw("DpadY")== 0)
					axisinuse=false;
				if (Input.GetKeyDown (KeyCode.JoystickButton0)) {
					boxdamage.attackdamage=hardatkdmg;
					downatk = true;
				}
				
				if (Input.GetKeyDown (KeyCode.JoystickButton3)&&!downatk) {
					boxdamage.attackdamage=hardatkdmg;
				audiosources[2].Play ();
					upatk = true;
				}
				if (Input.GetAxis("DpadX")< 0) {
					right = false;
					walking = true;
					pos.x -= speed * Time.deltaTime;
				}
				
				if (Input.GetKeyDown (KeyCode.JoystickButton2)&& !upatk && !downatk) {
					boxdamage.attackdamage=hardatkdmg;
				audiosources[4].Play ();
					frontatk = true;
				}
				
				if (Input.GetAxis("DpadX")> 0) {
					
					right = true;
					walking = true;
					pos.x += speed * Time.deltaTime;
				}
				if (Input.GetKeyDown (KeyCode.JoystickButton1) && !upatk && !downatk) {
					boxdamage.attackdamage=hardatkdmg;
				audiosources[4].Play ();

					frontatk = true;
				}
				
				if (Input.GetAxis("DpadY")< 0) {
					if (!ducking) {
						scale.y = 2;
						pos.y -= 0.45f;
						ducking = true;
						
					}
				} else {
					if (ducking) {
						scale.y = 4;
						pos.y += 0.45f;
						ducking = false;
					}
				}
				
				if (Input.GetKey (KeyCode.JoystickButton5) && !upatk && !frontatk && !downatk) {
				waittime=0.2f;
				GameObject projectile;
				int ran = Random.Range (0,2);
				if(counting&&elapsedtime<waittime){
					elapsedtime+=Time.deltaTime;
				}
				else{
					boxdamage.attackdamage=beamdmg;
					int a;
					
					if(right)
						a=1;
					else a=-1;
					GameObject prefab0 = (GameObject)Resources.Load ("zero");
					GameObject prefab1 = (GameObject)Resources.Load ("one");
					if(ran==1)
						projectile = Instantiate(prefab1);
					else 
						projectile= Instantiate(prefab0);
					
					projectile.GetComponent<zerowan>().direction=right;
					projectile.GetComponent<atkboxscript>().attackdamage=beamdmg;
					projectile.tag=myboxname;
					projectile.transform.position=new Vector3(pos.x+a*.2f, pos.y+.5f,0);
					
					
					
					
					shoot = true;
					counting=true;
					elapsedtime=0;
					
				}
				}
			else shoot = false;
				
				
				if (right)
					scale.x = 4;
				else 
					scale.x = -4;
				gameObject.transform.localScale = scale;
				gameObject.transform.position = pos; 
				playeranimator.SetBool ("walking", walking);
				playeranimator.SetBool ("jump", jumping);
				playeranimator.SetBool ("upattack", upatk);
				playeranimator.SetBool ("downattack", downatk);
				playeranimator.SetBool ("frontattack", frontatk);
				playeranimator.SetBool ("attack", atk);
				playeranimator.SetBool ("shooting", shoot);
				playeranimator.SetBool ("alive", alive);
			} else {//player == 2
				if (Input.GetKeyDown (KeyCode.UpArrow) && playerrigidbody.velocity.y >-0.1f&&playerrigidbody.velocity.y<0.1f) {
					jumping = true;
				audiosources[1].Play();
					playerrigidbody.AddForce (new Vector2 (0, jumpforce),ForceMode2D.Impulse);
				}
				if (Input.GetKeyDown (KeyCode.S)) {
					boxdamage.attackdamage=hardatkdmg;
				audiosources[3].Play();

					downatk = true;
				}
				
				if (Input.GetKey (KeyCode.W)&&!downatk) {
					boxdamage.attackdamage=hardatkdmg;
				audiosources[2].Play();

					upatk = true;
				}
				if (Input.GetKey (KeyCode.LeftArrow)) {
					right = false;
					walking = true;
					pos.x -= speed * Time.deltaTime;
				}
				
				if (Input.GetKeyDown (KeyCode.A) && !upatk && !downatk) {
					boxdamage.attackdamage=hardatkdmg;
				audiosources[2].Play();

					frontatk = true;
				}
				
				if (Input.GetKey (KeyCode.RightArrow)) {
					right = true;
					walking = true;
					pos.x += speed * Time.deltaTime;
				}
				if (Input.GetKeyDown (KeyCode.D) && !upatk && !downatk) {
					boxdamage.attackdamage=hardatkdmg;
				audiosources[2].Play();

					frontatk = true;
				}
				
				if (Input.GetKey (KeyCode.DownArrow)) {
					if (!ducking) {
						scale.y = 2;
						pos.y -= 0.45f;
						ducking = true;
						
					}
				} else {
					if (ducking) {
						scale.y = 4;
						pos.y += 0.45f;
						ducking = false;
					}
				}
				
				if (Input.GetKey (KeyCode.Q) && !upatk && !frontatk && !downatk) {
				waittime=0.2f;
				GameObject projectile;
				int ran = Random.Range (0,2);
				if(counting&&elapsedtime<waittime){
					elapsedtime+=Time.deltaTime;
				}
				else{
					boxdamage.attackdamage=beamdmg;
					int a;
					
					if(right)
						a=1;
				else a=-1;
				GameObject prefab0 = (GameObject)Resources.Load ("zero");
				GameObject prefab1 = (GameObject)Resources.Load ("one");
					if(ran==1)
						projectile = Instantiate(prefab1);
					else 
						projectile= Instantiate(prefab0);

				projectile.GetComponent<zerowan>().direction=right;
				projectile.GetComponent<atkboxscript>().attackdamage=beamdmg;
				projectile.tag=myboxname;
				projectile.transform.position=new Vector3(pos.x+a*.2f, pos.y+.5f,0);
					audiosources[0].Play();



					shoot = true;
				counting=true;
				elapsedtime=0;

				}
			}
			else {
					shoot = false;
					counting=false;
				
				}
				if (right)
					scale.x = 4;
				else 
					scale.x = -4;
				gameObject.transform.localScale = scale;
				gameObject.transform.position = pos; 
				playeranimator.SetBool ("walking", walking);
				playeranimator.SetBool ("jump", jumping);
				playeranimator.SetBool ("upattack", upatk);
				playeranimator.SetBool ("downattack", downatk);
				playeranimator.SetBool ("frontattack", frontatk);
				playeranimator.SetBool ("attack", atk);
				playeranimator.SetBool ("shooting", shoot);
				playeranimator.SetBool ("alive", alive);
			}

	}
	
	public void OnTriggerEnter2D(Collider2D col){
		if (col.gameObject.tag == enemyboxname) {
			hp-=GameObject.FindGameObjectWithTag (enemyboxname).GetComponent<atkboxscript>().attackdamage;
			playeranimator.SetBool("damaged",true);

		}
	}
	
}

