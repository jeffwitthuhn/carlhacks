﻿using UnityEngine;
using System.Collections;

public class andascript : MonoBehaviour {
	public bool right;
	public bool ducking;
	public bool alive;
	public bool upatk;
	public bool downatk;
	public bool frontatk;
	public bool atk; 
	public bool charging;
	public bool charged; 
	public bool jumping;
	public bool walking;
	public int player; 
	public float speed;
	public float jumpforce;
	public float hp;
	public float beamdmg;
	public float hardatkdmg;
	public float softatkdmg;
	float waittime;
	float elapsedtime;
	bool counting;
	bool axisinuse;
	Vector3 pos; 
	Vector3 scale; 
	Animator playeranimator;
	Rigidbody2D playerrigidbody;
	atkboxscript boxdamage;
	string enemyboxname;
	string myboxname;
	//Audiosource[] audiosources;
	AudioSource[] audiosources;

	// Use this for initialization
	void Start () {
		audiosources = GetComponents<AudioSource> ();
		boxdamage=gameObject.transform.GetChild (0).gameObject.GetComponent<atkboxscript>();
		if (gameObject.name.Substring (0,2) == "P1") {
			player = 1;
			enemyboxname="P2";
			myboxname="P1";

		} 
		else {
			player = 2;
			enemyboxname="P1";
			myboxname="P2";

		}
		if (player == 1)
			right = true;
		else {
			right = false; 
			scale=gameObject.transform.localScale;
			scale.x=-4;
			gameObject.transform.localScale=scale;
		}
		playerrigidbody = GetComponent<Rigidbody2D> ();
		playeranimator = GetComponent<Animator> ();
		alive = true;
		upatk = false;
		downatk = false;
		frontatk = false;
		atk = false;
		charging = false;
		charged = false;
		jumping = false;
		walking = false;
		counting = false;
		axisinuse = false;
		waittime = 1.1f;
		speed = 5;
		jumpforce = 10;
		beamdmg = 5;
		hardatkdmg = 20;
		softatkdmg = 10;
		hp = 1000;
	}
	
	// Update is called once per frame
	void Update () {
		upatk = false;
		downatk = false;
		frontatk = false;
		atk = false;
		jumping = false;
		walking = false;
		if (charging) {
			if(charged)
				waittime=0.5f;
			else waittime=1.5f;
			if(!counting){
				elapsedtime=0;
				counting=true;
			}
			else {
				elapsedtime+=Time.deltaTime;
			}
			if(elapsedtime>=waittime){
				charged = !charged;
				charging = false;
				counting=false;
			}
		} else {
			boxdamage.attackdamage = 0;
			pos = gameObject.transform.position;
			scale = gameObject.transform.localScale;
			if (player == 1) {
				if (Input.GetAxisRaw("DpadY")> 0 &&pos.y<2&& playerrigidbody.velocity.y >-0.1f&&playerrigidbody.velocity.y<0.1f) {
					jumping = true;
					if(!axisinuse)
						playerrigidbody.AddForce (new Vector2 (0, jumpforce), ForceMode2D.Impulse);
					axisinuse=true;
				}
				if(axisinuse&&Input.GetAxisRaw("DpadY")== 0)
					axisinuse=false;
				if (Input.GetKeyDown (KeyCode.JoystickButton0)) {
						boxdamage.attackdamage=hardatkdmg;
						audiosources[0].Play();
						downatk = true;
					}

				if (Input.GetKeyDown (KeyCode.JoystickButton3)&&!downatk) {
						boxdamage.attackdamage=hardatkdmg;
					audiosources[1].Play();
						upatk = true;
				}
				if (Input.GetAxis("DpadX")< 0) {
					right = false;
					walking = true;
					pos.x -= speed * Time.deltaTime;
				}

				if (Input.GetKeyDown (KeyCode.JoystickButton2)&& !upatk && !downatk) {
						boxdamage.attackdamage=hardatkdmg;
					audiosources[0].Play();
						frontatk = true;
					}
			
				if (Input.GetAxis("DpadX")> 0) {
					right = true;
					walking = true;
					pos.x += speed * Time.deltaTime;
				}
				if (Input.GetKeyDown (KeyCode.JoystickButton1) && !upatk && !downatk) {
						boxdamage.attackdamage=hardatkdmg;
						frontatk = true;
					audiosources[2].Play ();
				}

				if (Input.GetAxis("DpadY")< 0) {
					if (!ducking) {
						scale.y = 2;
						pos.y -= 0.45f;
						ducking = true;
					
					}
				} else {
					if (ducking) {
						scale.y = 4;
						pos.y += 0.45f;
						ducking = false;
					}
				}

				if (Input.GetKeyDown (KeyCode.JoystickButton5) && !upatk && !frontatk && !downatk) {
					boxdamage.attackdamage=beamdmg;
					int a;
					if(right)
						a=1;
					else 
						a=-1;
					if(charged)
					for(int i=0; i<30; i++){
						GameObject prefab = (GameObject)Resources.Load ("lazersquare");
						GameObject lazer = Instantiate (prefab) as GameObject;
						lazer.tag=myboxname;
						lazer.transform.position = new Vector3(pos.x+a*0.2f+a*i*0.2f, pos.y+0.5f,0);
						Destroy (lazer,0.8f+i*0.05f);
					}
					             audiosources[2].Play ();
					charging = true;
				}


				if (right)
					scale.x = 4;
				else 
					scale.x = -4;
				gameObject.transform.localScale = scale;
				gameObject.transform.position = pos; 
				playeranimator.SetBool ("moving", walking);
				playeranimator.SetBool ("jump", jumping);
				playeranimator.SetBool ("upattack", upatk);
				playeranimator.SetBool ("downattack", downatk);
				playeranimator.SetBool ("forwardattack", frontatk);
				playeranimator.SetBool ("attack", atk);
				playeranimator.SetBool ("charging", charging);
				playeranimator.SetBool ("charged", charged);
				playeranimator.SetBool ("alive", alive);
			} else {//player == 2
				if (Input.GetKeyDown (KeyCode.UpArrow) && playerrigidbody.velocity.y >-0.1f&&playerrigidbody.velocity.y<0.1f) {
							audiosources[5].Play ();

							jumping = true;
					playerrigidbody.AddForce (new Vector2 (0, jumpforce),ForceMode2D.Impulse);
				}
				if (Input.GetKeyDown (KeyCode.S)) {
					boxdamage.attackdamage=hardatkdmg;
							audiosources[3].Play ();

					downatk = true;
				}
				
				if (Input.GetKey (KeyCode.W)&&!downatk) {
					boxdamage.attackdamage=hardatkdmg;
					upatk = true;
				}
				if (Input.GetKey (KeyCode.LeftArrow)) {
					right = false;
					walking = true;
					pos.x -= speed * Time.deltaTime;
				}
				
				if (Input.GetKeyDown (KeyCode.A) && !upatk && !downatk) {
					boxdamage.attackdamage=hardatkdmg;
					frontatk = true;
				}
				
				if (Input.GetKey (KeyCode.RightArrow)) {
					right = true;
					walking = true;
					pos.x += speed * Time.deltaTime;
				}
				if (Input.GetKeyDown (KeyCode.D) && !upatk && !downatk) {
					boxdamage.attackdamage=hardatkdmg;
					frontatk = true;
				}
				
				if (Input.GetKey (KeyCode.DownArrow)) {
					if (!ducking) {
						scale.y = 2;
						pos.y -= 0.45f;
						ducking = true;
						
					}
				} else {
					if (ducking) {
						scale.y = 4;
						pos.y += 0.45f;
						ducking = false;
					}
				}
				
				if (Input.GetKeyDown (KeyCode.Q) && !upatk && !frontatk && !downatk) {
					boxdamage.attackdamage=beamdmg;
					int a;
					if(right)
						a=1;
					else 
						a=-1;
					if(charged)
						for(int i=0; i<30; i++){
							GameObject prefab = (GameObject)Resources.Load ("lazersquare");
							GameObject lazer = Instantiate (prefab) as GameObject;
							lazer.tag=myboxname;
							lazer.transform.position = new Vector3(pos.x+a*0.2f+a*i*0.2f, pos.y+0.5f,0);
							Destroy (lazer,0.8f+i*0.05f);
						}
					charging = true;
				}
				
				
				if (right)
					scale.x = 4;
				else 
					scale.x = -4;
				gameObject.transform.localScale = scale;
				gameObject.transform.position = pos; 
				playeranimator.SetBool ("moving", walking);
				playeranimator.SetBool ("jump", jumping);
				playeranimator.SetBool ("upattack", upatk);
				playeranimator.SetBool ("downattack", downatk);
				playeranimator.SetBool ("forwardattack", frontatk);
				playeranimator.SetBool ("attack", atk);
				playeranimator.SetBool ("charging", charging);
				playeranimator.SetBool ("charged", charged);
				playeranimator.SetBool ("alive", alive);
			}
		}
	}

	public void OnTriggerEnter2D(Collider2D col){
		if (col.gameObject.tag == enemyboxname) {
			hp-=GameObject.FindGameObjectWithTag (enemyboxname).GetComponent<atkboxscript>().attackdamage;
			playeranimator.SetBool("damaged",true);
			}
	}

}

